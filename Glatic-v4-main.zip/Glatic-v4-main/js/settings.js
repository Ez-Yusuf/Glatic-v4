function oG() {
  localStorage.setItem("cloak", "Glatic | Learning");
  location.reload()
}

function googleClassroom() {
  localStorage.setItem("cloak", "classroom");
  location.reload()
}

function canvasApp() {
  localStorage.setItem("cloak", "canvas");
  location.reload()
}

function powerSchool() {
  localStorage.setItem("cloak", "ps");
  location.reload()
}

function google() {
  localStorage.setItem("cloak", "google");
  location.reload()
}

function googleDrive() {
  localStorage.setItem("cloak", "drive");
  location.reload()
}

function pEnable() {
  localStorage.setItem("panic", "on");
  location.reload()
}

function pDisable() {
  localStorage.setItem("panic", "off");
  location.reload()
}

function DarkTheme() {
  localStorage.setItem("theme", "dark");
  location.reload()
}

function LightTheme() {
  localStorage.setItem("theme", "light");
  location.reload()
}

function AmoledTheme() {
  localStorage.setItem("theme", "amoled");
  location.reload()
}

function UglyTheme() {
  localStorage.setItem("theme", "ugly");
  location.reload()
}

